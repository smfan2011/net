/*
 * x86linuxcompiletest2.c
 *
 * Code generation for model "x86linuxcompiletest2".
 *
 * Model version              : 1.12
 * Simulink Coder version : 9.4 (R2020b) 29-Jul-2020
 * C source code generated on : Wed Mar 17 14:15:18 2021
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Linux 64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "x86linuxcompiletest2.h"
#include "x86linuxcompiletest2_private.h"

/* user code (top of source file) */
/* System '<Root>' */
extern void rt_OneStep(void);
int udp_socket_fd;
struct sockaddr_in dest_addr = { 0 };

char buf[1024] = { 0 };

struct itimerval tv, oldtv;
unsigned long cnt = 0;
real_T ConTs;
int udp_init(void)
{
  udp_socket_fd = socket(AF_INET, SOCK_DGRAM, 0);
  if (udp_socket_fd == -1) {
    perror("socket failed!\n");
    return -1;
  }

  dest_addr.sin_family = AF_INET;
  dest_addr.sin_port = htons(60000);
  dest_addr.sin_addr.s_addr = inet_addr("192.168.1.2");
}

void set_timer()
{
  tv.it_interval.tv_sec = 0;           //1s
  tv.it_interval.tv_usec = ConTs;      //100; //100us
  tv.it_value.tv_sec = 0;
  tv.it_value.tv_usec = ConTs;
  if (setitimer(ITIMER_REAL, &tv, &oldtv)) {
    fprintf(stderr, "Failed to start timer: %s\n", strerror(errno));
  }
}

void signal_handler(int signo)
{
  switch (signo)
  {
   case SIGALRM:
    rt_OneStep();
    sprintf(buf,"x86test:%ld",cnt++);
    buf[3] = Datachange1;
    buf4] = Datachange2;
    sendto(udp_socket_fd, buf, strlen(buf), 0, (struct sockaddr *)&dest_addr,
           sizeof(dest_addr));
    if (strcmp(buf, "quit") == 0) {
      break;
    }

    memset(buf,0,sizeof(buf));
    break;

   default:
    break;
  }
}

/* Exported block states */
uint8_T Datachange1;                   /* '<Root>/Data Store Memory1' */
uint8_T Datachange2;                   /* '<Root>/Data Store Memory2' */

/* Block states (default storage) */
DW_x86linuxcompiletest2_T x86linuxcompiletest2_DW;

/* Real-time model */
static RT_MODEL_x86linuxcompiletest2_T x86linuxcompiletest2_M_;
RT_MODEL_x86linuxcompiletest2_T *const x86linuxcompiletest2_M =
  &x86linuxcompiletest2_M_;
static void rate_scheduler(void);

/*
 *   This function updates active task flag for each subrate.
 * The function is called at model base rate, hence the
 * generated code self-manages all its subrates.
 */
static void rate_scheduler(void)
{
  /* Compute which subrates run during the next base time step.  Subrates
   * are an integer multiple of the base rate counter.  Therefore, the subtask
   * counter is reset when it reaches its limit (zero means run).
   */
  (x86linuxcompiletest2_M->Timing.TaskCounters.TID[1])++;
  if ((x86linuxcompiletest2_M->Timing.TaskCounters.TID[1]) > 1) {/* Sample time: [1.0s, 0.0s] */
    x86linuxcompiletest2_M->Timing.TaskCounters.TID[1] = 0;
  }
}

/* Model step function */
void x86linuxcompiletest2_step(void)
{
  uint8_T rtb_FixPtSum1_g;

  /* Outputs for Atomic SubSystem: '<Root>/Subsystem' */
  /* DataStoreWrite: '<S1>/Data Store Write1' incorporates:
   *  UnitDelay: '<S3>/Output'
   */
  Datachange1 = x86linuxcompiletest2_DW.Output_DSTATE_m;

  /* Sum: '<S4>/FixPt Sum1' incorporates:
   *  Constant: '<S4>/FixPt Constant'
   *  UnitDelay: '<S3>/Output'
   */
  rtb_FixPtSum1_g = (uint8_T)((uint32_T)x86linuxcompiletest2_DW.Output_DSTATE_m
    + x86linuxcompiletest2_P.FixPtConstant_Value);

  /* Switch: '<S5>/FixPt Switch' */
  if (rtb_FixPtSum1_g > x86linuxcompiletest2_P.CounterLimited_uplimit) {
    /* Update for UnitDelay: '<S3>/Output' incorporates:
     *  Constant: '<S5>/Constant'
     */
    x86linuxcompiletest2_DW.Output_DSTATE_m =
      x86linuxcompiletest2_P.Constant_Value;
  } else {
    /* Update for UnitDelay: '<S3>/Output' */
    x86linuxcompiletest2_DW.Output_DSTATE_m = rtb_FixPtSum1_g;
  }

  /* End of Switch: '<S5>/FixPt Switch' */
  /* End of Outputs for SubSystem: '<Root>/Subsystem' */
  if (x86linuxcompiletest2_M->Timing.TaskCounters.TID[1] == 0) {
    /* Outputs for Atomic SubSystem: '<Root>/Subsystem1' */
    /* DataStoreWrite: '<S2>/Data Store Write1' incorporates:
     *  UnitDelay: '<S6>/Output'
     */
    Datachange2 = x86linuxcompiletest2_DW.Output_DSTATE;

    /* Sum: '<S7>/FixPt Sum1' incorporates:
     *  Constant: '<S7>/FixPt Constant'
     *  UnitDelay: '<S6>/Output'
     */
    rtb_FixPtSum1_g = (uint8_T)((uint32_T)x86linuxcompiletest2_DW.Output_DSTATE
      + x86linuxcompiletest2_P.FixPtConstant_Value_i);

    /* Switch: '<S8>/FixPt Switch' */
    if (rtb_FixPtSum1_g > x86linuxcompiletest2_P.CounterLimited_uplimit_m) {
      /* Update for UnitDelay: '<S6>/Output' incorporates:
       *  Constant: '<S8>/Constant'
       */
      x86linuxcompiletest2_DW.Output_DSTATE =
        x86linuxcompiletest2_P.Constant_Value_g;
    } else {
      /* Update for UnitDelay: '<S6>/Output' */
      x86linuxcompiletest2_DW.Output_DSTATE = rtb_FixPtSum1_g;
    }

    /* End of Switch: '<S8>/FixPt Switch' */
    /* End of Outputs for SubSystem: '<Root>/Subsystem1' */
  }

  /* Matfile logging */
  rt_UpdateTXYLogVars(x86linuxcompiletest2_M->rtwLogInfo,
                      (&x86linuxcompiletest2_M->Timing.taskTime0));

  /* signal main to stop simulation */
  {                                    /* Sample time: [0.5s, 0.0s] */
    if ((rtmGetTFinal(x86linuxcompiletest2_M)!=-1) &&
        !((rtmGetTFinal(x86linuxcompiletest2_M)-
           x86linuxcompiletest2_M->Timing.taskTime0) >
          x86linuxcompiletest2_M->Timing.taskTime0 * (DBL_EPSILON))) {
      rtmSetErrorStatus(x86linuxcompiletest2_M, "Simulation finished");
    }
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++x86linuxcompiletest2_M->Timing.clockTick0)) {
    ++x86linuxcompiletest2_M->Timing.clockTickH0;
  }

  x86linuxcompiletest2_M->Timing.taskTime0 =
    x86linuxcompiletest2_M->Timing.clockTick0 *
    x86linuxcompiletest2_M->Timing.stepSize0 +
    x86linuxcompiletest2_M->Timing.clockTickH0 *
    x86linuxcompiletest2_M->Timing.stepSize0 * 4294967296.0;
  rate_scheduler();
}

/* Model initialize function */
void x86linuxcompiletest2_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)x86linuxcompiletest2_M, 0,
                sizeof(RT_MODEL_x86linuxcompiletest2_T));
  rtmSetTFinal(x86linuxcompiletest2_M, -1);
  x86linuxcompiletest2_M->Timing.stepSize0 = 0.5;

  /* Setup for data logging */
  {
    static RTWLogInfo rt_DataLoggingInfo;
    rt_DataLoggingInfo.loggingInterval = NULL;
    x86linuxcompiletest2_M->rtwLogInfo = &rt_DataLoggingInfo;
  }

  /* Setup for data logging */
  {
    rtliSetLogXSignalInfo(x86linuxcompiletest2_M->rtwLogInfo, (NULL));
    rtliSetLogXSignalPtrs(x86linuxcompiletest2_M->rtwLogInfo, (NULL));
    rtliSetLogT(x86linuxcompiletest2_M->rtwLogInfo, "tout");
    rtliSetLogX(x86linuxcompiletest2_M->rtwLogInfo, "");
    rtliSetLogXFinal(x86linuxcompiletest2_M->rtwLogInfo, "");
    rtliSetLogVarNameModifier(x86linuxcompiletest2_M->rtwLogInfo, "rt_");
    rtliSetLogFormat(x86linuxcompiletest2_M->rtwLogInfo, 4);
    rtliSetLogMaxRows(x86linuxcompiletest2_M->rtwLogInfo, 0);
    rtliSetLogDecimation(x86linuxcompiletest2_M->rtwLogInfo, 1);
    rtliSetLogY(x86linuxcompiletest2_M->rtwLogInfo, "");
    rtliSetLogYSignalInfo(x86linuxcompiletest2_M->rtwLogInfo, (NULL));
    rtliSetLogYSignalPtrs(x86linuxcompiletest2_M->rtwLogInfo, (NULL));
  }

  /* states (dwork) */
  (void) memset((void *)&x86linuxcompiletest2_DW, 0,
                sizeof(DW_x86linuxcompiletest2_T));

  /* exported global states */
  Datachange1 = 0U;
  Datachange2 = 0U;

  /* Matfile logging */
  rt_StartDataLoggingWithStartTime(x86linuxcompiletest2_M->rtwLogInfo, 0.0,
    rtmGetTFinal(x86linuxcompiletest2_M),
    x86linuxcompiletest2_M->Timing.stepSize0, (&rtmGetErrorStatus
    (x86linuxcompiletest2_M)));

  /* Start for DataStoreMemory: '<Root>/Data Store Memory' */
  ConTs = x86linuxcompiletest2_P.Ts * 1000.0 * 1000.0;

  /* Start for DataStoreMemory: '<Root>/Data Store Memory1' */
  Datachange1 = x86linuxcompiletest2_P.DataStoreMemory1_InitialValue;

  /* Start for DataStoreMemory: '<Root>/Data Store Memory2' */
  Datachange2 = x86linuxcompiletest2_P.DataStoreMemory2_InitialValue;

  {
    {
      /* user code (Initialize function Header) */

      /* System '<Root>' */
      udp_init();
      signal(SIGALRM,signal_handler);
      set_timer();

      /* SystemInitialize for Atomic SubSystem: '<Root>/Subsystem' */
      /* InitializeConditions for UnitDelay: '<S3>/Output' */
      x86linuxcompiletest2_DW.Output_DSTATE_m =
        x86linuxcompiletest2_P.Output_InitialCondition;

      /* End of SystemInitialize for SubSystem: '<Root>/Subsystem' */

      /* SystemInitialize for Atomic SubSystem: '<Root>/Subsystem1' */
      /* InitializeConditions for UnitDelay: '<S6>/Output' */
      x86linuxcompiletest2_DW.Output_DSTATE =
        x86linuxcompiletest2_P.Output_InitialCondition_l;

      /* End of SystemInitialize for SubSystem: '<Root>/Subsystem1' */
    }
  }
}

/* Model terminate function */
void x86linuxcompiletest2_terminate(void)
{
  {
    /* user code (Terminate function Header) */

    /* System '<Root>' */
    close(udp_socket_fd);
  }
}
