/*
 * x86linuxcompiletest2_data.c
 *
 * Code generation for model "x86linuxcompiletest2".
 *
 * Model version              : 1.12
 * Simulink Coder version : 9.4 (R2020b) 29-Jul-2020
 * C source code generated on : Wed Mar 17 14:15:18 2021
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Linux 64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "x86linuxcompiletest2.h"
#include "x86linuxcompiletest2_private.h"

/* Block parameters (default storage) */
P_x86linuxcompiletest2_T x86linuxcompiletest2_P = {
  /* Variable: Ts
   * Referenced by: '<Root>/Data Store Memory'
   */
  0.5,

  /* Mask Parameter: CounterLimited_uplimit
   * Referenced by: '<S5>/FixPt Switch'
   */
  7U,

  /* Mask Parameter: CounterLimited_uplimit_m
   * Referenced by: '<S8>/FixPt Switch'
   */
  5U,

  /* Computed Parameter: Constant_Value
   * Referenced by: '<S5>/Constant'
   */
  0U,

  /* Computed Parameter: Output_InitialCondition
   * Referenced by: '<S3>/Output'
   */
  0U,

  /* Computed Parameter: FixPtConstant_Value
   * Referenced by: '<S4>/FixPt Constant'
   */
  1U,

  /* Computed Parameter: Constant_Value_g
   * Referenced by: '<S8>/Constant'
   */
  0U,

  /* Computed Parameter: Output_InitialCondition_l
   * Referenced by: '<S6>/Output'
   */
  0U,

  /* Computed Parameter: FixPtConstant_Value_i
   * Referenced by: '<S7>/FixPt Constant'
   */
  1U,

  /* Computed Parameter: DataStoreMemory1_InitialValue
   * Referenced by: '<Root>/Data Store Memory1'
   */
  0U,

  /* Computed Parameter: DataStoreMemory2_InitialValue
   * Referenced by: '<Root>/Data Store Memory2'
   */
  0U
};
